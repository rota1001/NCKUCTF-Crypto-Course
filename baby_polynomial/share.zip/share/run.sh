#!/bin/sh

exec 2>/dev/null
cd /home/chal
timeout 60 /home/chal/server.py
